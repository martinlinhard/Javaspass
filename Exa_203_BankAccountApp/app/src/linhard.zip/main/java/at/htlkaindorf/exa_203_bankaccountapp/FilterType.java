package at.htlkaindorf.exa_203_bankaccountapp;

public enum FilterType {
    ALL,
    STUDENT,
    GIRO;
}
