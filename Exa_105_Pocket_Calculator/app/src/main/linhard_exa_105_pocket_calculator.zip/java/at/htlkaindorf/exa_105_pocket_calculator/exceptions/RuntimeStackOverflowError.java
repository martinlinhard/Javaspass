package at.htlkaindorf.exa_105_pocket_calculator.exceptions;

public class RuntimeStackOverflowError extends RuntimeException {
    public RuntimeStackOverflowError(String message) {
        super(message);
    }
}
