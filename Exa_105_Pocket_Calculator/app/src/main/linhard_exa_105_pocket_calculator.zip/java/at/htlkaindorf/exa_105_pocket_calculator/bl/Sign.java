package at.htlkaindorf.exa_105_pocket_calculator.bl;

public enum Sign {
    Plus,
    Minus,
    Multiply,
    Divide;
}
