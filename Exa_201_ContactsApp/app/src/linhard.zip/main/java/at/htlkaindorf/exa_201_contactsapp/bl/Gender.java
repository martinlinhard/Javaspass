package at.htlkaindorf.exa_201_contactsapp.bl;

public enum Gender {
    MALE,
    FEMALE,
    OTHER;
}
