package at.htlkaindorf.exa_206_pethome.beans;

public enum MyGender {
    MALE,
    FEMALE;
}
